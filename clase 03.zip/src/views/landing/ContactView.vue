<template>
  <p>Contact works!</p>
</template>
