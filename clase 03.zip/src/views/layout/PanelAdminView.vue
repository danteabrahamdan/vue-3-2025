<template>
  <p>Admin works!</p>
</template>
