<template>
  <p>Lading works!</p>
</template>
