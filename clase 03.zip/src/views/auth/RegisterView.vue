<template>
  <p>Register works!</p>
</template>
